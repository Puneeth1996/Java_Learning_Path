package com.spiegelberger.app.ws.ui.model.request;

public class PasswordResetRequestModel {
	
	private String email;

	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
