package com.spiegelberger.app.ws.shared;

public enum Roles {

	ROLE_USER, ROLE_ADMIN
}
